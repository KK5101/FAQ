import React from "react";
import { useState } from "react";

const FAQItem = ({ question, answer }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="faq-item">
      <div
        style={{ backgroundColor: isOpen ? "green" : "red" }}
        onClick={() => setIsOpen(!isOpen)}
      >
        <span>
          💬 <strong>Question:</strong> "{question}"
        </span>
        <span className="toggle-icon">{isOpen ? "▲" : "▼"}</span>
      </div>
      {isOpen && (
        <div className="faq-answer">
          <strong>Answer:</strong> {answer}
        </div>
      )}
    </div>
  );
};

export default FAQItem;
