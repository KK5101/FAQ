import React from "react";
import FAQItem from "./FAQItem";

const questions = [
  { question: "What is the question?", answer: "This is the answer." },
  {
    question: "What is React?",
    answer: "React is a JavaScript library for building user interfaces.",
  },
  {
    question: "How does useState work?",
    answer:
      "useState is a React hook for managing state in functional components.",
  },
];

const FAQList = () => {
  return (
    <div className="faq-list">
      {questions.map((q, index) => (
        <FAQItem key={index} question={q.question} answer={q.answer} />
      ))}
    </div>
  );
};

export default FAQList;
